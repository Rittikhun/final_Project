//
//  CustomPointAnnotation.swift
//  UserLoginAndRegistration
//
//  Created by Mark on 3/8/17.
//  Copyright © 2017 Sergey Kargopolov. All rights reserved.
//

import UIKit
import MapKit

class CustomPointAnnotation: MKPointAnnotation {
    
    var pinCustomImageName:String!

}
